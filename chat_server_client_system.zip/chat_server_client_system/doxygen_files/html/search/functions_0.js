var searchData=
[
  ['connect_5frequest',['connect_request',['../client_8c.html#ad0684a9320b57113b849c8cea524263d',1,'connect_request(int *sockfd, struct sockaddr_in *server_address, char *argv[]):&#160;client.c'],['../server_8c.html#a072aa95d11e58310cd8f5839acbd34a7',1,'connect_request(int *server_sockfd, struct sockaddr_in *my_addr):&#160;server.c']]],
  ['connection_5faccept',['connection_accept',['../server_8c.html#afdd1dd6be1c534c0835552736c135df3',1,'server.c']]]
];
