var searchData=
[
  ['login_5fsignup',['login_signup',['../client_8c.html#a7dd745f88bc7c1794bd252cc29d7da90',1,'client.c']]]
];
