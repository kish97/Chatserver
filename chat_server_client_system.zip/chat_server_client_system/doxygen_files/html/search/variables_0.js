var searchData=
[
  ['alright',['alright',['../header_8h.html#af1e2b8c369d2005220d9a39fbec99c9a',1,'header.h']]]
];
