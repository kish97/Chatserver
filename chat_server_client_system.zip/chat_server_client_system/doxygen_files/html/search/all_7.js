var searchData=
[
  ['login_5fsignup',['login_signup',['../client_8c.html#a7dd745f88bc7c1794bd252cc29d7da90',1,'client.c']]],
  ['login_5fuser_5ferror',['login_user_error',['../header_8h.html#aeb256a8f2e88c60e5fb476a2e3b45c2c',1,'header.h']]]
];
