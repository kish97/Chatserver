var searchData=
[
  ['num_5fclient',['NUM_CLIENT',['../header_8h.html#a8e4efcf2b8b9003bdbb2c2125302c8b6',1,'header.h']]]
];
