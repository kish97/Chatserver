var searchData=
[
  ['send_5frecv',['send_recv',['../server_8c.html#a9f6c4199d926897063ff4b77a30eca97',1,'server.c']]],
  ['send_5fto_5fall',['send_to_all',['../server_8c.html#a03d301b2db34e38809e91185c98c8ace',1,'server.c']]],
  ['server_2ec',['server.c',['../server_8c.html',1,'']]],
  ['signup_5fpassword',['signup_password',['../header_8h.html#ab80867be16adc714c5374a7d223bfce8',1,'header.h']]]
];
