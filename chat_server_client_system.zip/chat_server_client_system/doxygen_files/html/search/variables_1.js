var searchData=
[
  ['client_5fsockfd',['client_sockfd',['../structdatabase.html#adcd79dabf165c46577baa01e0a363078',1,'database']]]
];
