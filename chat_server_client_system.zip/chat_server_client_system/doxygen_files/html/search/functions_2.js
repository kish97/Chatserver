var searchData=
[
  ['handle_5fsigint',['handle_sigint',['../client_8c.html#a8bfc90b3fb9344e9caafec953baacc0b',1,'client.c']]]
];
