/* Server side C program */

#include "header.h"				//!< including header.h file

/*! sending messages to all clients. */
void send_to_all(int j, int i, int server_sockfd, int nbytes_recvd, char *recv_buf, fd_set *master)
{
	int x,yy,client_id;				/**< iterative variable and temporary variable to store client_sockfd */
	char sender_name[15];				/**< character array to store client name for sending to respective client */
	char content[2]=":";				/**< Passing this Character array to clients for readability */

	if (FD_ISSET(j, master))
	{
		/** condition for not to sent to the server and to the client from whom it received. */
		if (j != server_sockfd && j != i) 
		{
			for(x=0;x<40;x++)
			{	
				yy=db[x].client_sockfd;
				client_id=i;

				/**corresponding username is copied.*/
				if(yy == client_id)
				{
					strcpy(sender_name,db[x].user_name);
					break;
				}
			}
			
			/** sending data to clients.*/		
			send(j, sender_name, strlen(sender_name), 0);
			send(j, content, strlen(content), 0);
			
			/** if send returns -1 then message is not sent due to an error.*/
			if (send(j, recv_buf, nbytes_recvd, 0) == -1)
			{
				error("send");
			}
		}
	}
}

/*! receiving message from client. */		
void send_recv(int i, fd_set *master, int server_sockfd, int fdmax)
{
	int nbytes_recvd,j,s;					/**< status holder for receive function and a loop variable */
	int flag = 0,flag5=0,flag8=0;				/**< variable to hold a flag variable */
	int client_id,yy;					/**< variable to store client id's */
	char recv_buf[BUFSIZE];					/**< Character array to store buffer message */
	char sender_name[15];					/**< temporary character array to store username and and message to be sent */
	char receiver_name[50],sender_message[50];int index;	/**< To store message and receiver name in an array */
	char *p;						/**< pointer to store strchr function result */
	char user_name[50];					/**< character array to store username for displaying active clients */
	int length;						/**< to hold length of username */
	char temp[25],temp1[200];				/**< character array for temporary storage */
	int y;							/**< variable to hold result of strcmp function */
	char *q;						/**< variable to hold the result of strstr function */
	int k,l,zz;						/**< iteration variables */
	char ch[50][200]={0},ch1=0;				/**< character array to store usernames and password from file and temporary 									     variable */
	char buf_message[200];					/**< temporary character array for storing messages from files */
	char content[2]=":";					/**< Passing this Character array to clients for readability */

	/*following declarations for displaying error messages to client */
	char no_user[15]="no such user";
	char not_active[90]="user is not currently active and messages will be sent once he/she became active\n";
	char message1[30]="dont send to yourself\n";
	char not_format[50]="send in legitimate format";
	
	FILE *outfile;						/**< creating a file pointer */
	
	/** opening file for reading contents.*/
  	outfile = fopen("database.txt","a+");

  	/** ch is to store entire file,ch1 is for reading file char by char.*/
  	ch1=getc(outfile);
	l=0;
	while(!feof(outfile))
  	{
    		k=0;
    		while(ch1!='\n')
    		{
      			ch[l][k]=ch1;
      			k++;
      			ch1=getc(outfile);
    		}
    		ch[l][k]='\0';
    		ch1=getc(outfile);
    		l++;
  	}
	fclose(outfile);


	/** If the number of received bytes is 0 then the socket is closed else sending messages to other clients.*/
	memset(recv_buf,'\0',BUFSIZE);
	nbytes_recvd = recv(i, recv_buf, BUFSIZE, 0);
	if(nbytes_recvd <=0)
	{	
		/** removing corresponding client from structure.*/
		for(s=0;s<40;s++)
		{
			 if(i == db[s].client_sockfd)
			 {
				printf("%s closed\n",db[s].user_name);
				strcpy(temp,db[s].user_name);
				strcpy(db[s].user_name,"0");  
				db[s].client_sockfd = 0;
			 }
		}

		if (nbytes_recvd == 0) 
		{
			printf("socket %d hung up\n", i);
		}
		else 
		{
			error("recv");
		}
		close(i);
		FD_CLR(i, master);
		
		for(s=0;s<40;s++)
		{
			/** if the client logged in multiple devices, 
			    then if he closes in one device/terminal then it will be closed in other logged areas also 
			    and removing from the database. */
			if(!(strcmp(db[s].user_name,temp)))
			{
				printf("%s closed\n",db[s].user_name);
				printf("socket %d hung up\n", db[s].client_sockfd);
				close(db[s].client_sockfd);
				FD_CLR(db[s].client_sockfd, master);
				strcpy(db[s].user_name,"0");  
				db[s].client_sockfd = 0;
			}
		}
	}

	else
	{
		for(zz=0;zz<strlen(recv_buf);zz++)
		{
			if(recv_buf[zz] == ':')
			{
				flag8=1;
				break;
			}
		}
		if(flag8 == 1)
		{
			/** to split receiver name and senders message. */
			p = strchr(recv_buf, ':');
 			strncpy(receiver_name,recv_buf,p-recv_buf);
 			index = p-recv_buf+1;
 			strncpy(sender_message,recv_buf+index,strlen(recv_buf));

			/** to store sender name.*/
			for(s=0;s<40;s++)
			{	
				yy=db[s].client_sockfd;
				client_id=i;

				if(yy == client_id)
				{
					strcpy(sender_name,db[s].user_name);
					break;
				}
			}

			/** checking in the database whether client is sending to the registered user.*/
			if((strcmp("all",receiver_name))&&(strcmp("active",receiver_name))&&(strcmp("logs",receiver_name)))
			{
				for(s=0;s<50;s++)
				{	
					q=strstr(ch[s],receiver_name);
					s++; 		
					if(q)
					{
						y = strcmp(q,receiver_name);	
						if(!y)
						{
							flag5=1;
							break;	
						}
					}
				}	
			}
		
			/** if he is a registered user then searching in the active client list and sending messages accordingly.*/
			if(flag5 == 1)
			{
				for(s=0;s<40;s++)
				{
					/** checking in the active user list whether a user typed username is present or not.*/
					if(strcmp(db[s].user_name,receiver_name)==0)
					{
						flag = 1;
						if(i == db[s].client_sockfd)
						{
							send(db[s].client_sockfd, message1, strlen(message1), 0);
						}
						else
						{	
							/** creating and storing messages in a receiver database.*/
							FILE *outfile;	
							outfile=fopen (receiver_name,"a+");
							fprintf(outfile,"%s to %s:%s\n",sender_name,receiver_name,sender_message);
							fclose(outfile);

							/** creating and storing messages in a sender database.*/
							outfile=fopen (sender_name,"a+");
							fprintf(outfile,"%s to %s :%s\n",sender_name,receiver_name,sender_message);
							fclose(outfile);
					
							/** sending to a respective client.*/
							send(db[s].client_sockfd, sender_name, strlen(sender_name), 0);
							send(db[s].client_sockfd, content, strlen(content), 0);
							send(db[s].client_sockfd, sender_message,strlen(sender_message),0);
						}	
					}
			
					/** this is for checking whether the same user is logged more than one, then sending to all of his/her logged devices.*/
					if(s != 39)	
					{
						continue;
					}
			
					/** after message sent and completion of loop, character arrays are made empty.*/
					if((s == 39)&&(flag == 1))
					{
						memset(sender_name,'\0', BUFSIZE);
						memset(sender_message,'\0', BUFSIZE);
					}	

				}	
			}
	
			/** if the user enters all ,then following code will work.*/
			if(strcmp(receiver_name,"all")==0)
			{ 	
				flag = 1;
				for(j = 0; j <= fdmax; j++)
				{	
					/** this is for not to sent to him/her. */
					if(i != db[j].client_sockfd)
					{	FILE *outfile;
					
						if(strlen(db[j].user_name))
						{	
							/** creating and storing messages in a receiver database */
							outfile=fopen (db[j].user_name,"a+");
							fprintf(outfile,"%s to %s:%s\n",sender_name,db[j].user_name,sender_message);
							fclose(outfile);
						
							/** creating and storing messages in a sender database */
							outfile=fopen (sender_name,"a+");
							fprintf(outfile,"%s to %s:%s\n",sender_name,db[j].user_name,sender_message);
							fclose(outfile);
						}
					}

					/// This function sends client socket_fd, server sockfd, 
					/// number of bytes to be transmitted,message and master set.
					send_to_all(j, i, server_sockfd, nbytes_recvd, sender_message, master );
				}
			}

			/** if the user presses logs keyword, then the messages stored in his/her database are displayed to him.*/
			if(strcmp(receiver_name,"logs")==0)
			{	
				flag = 1;
				outfile=fopen (sender_name,"a+");
				while(fscanf(outfile,"%[^\n]\n", buf_message)!=EOF)
				{
					/** adding a newline character to that message for user readability.*/
					strcat(buf_message,"\n");
					send(i,buf_message, strlen(buf_message), 0);
					strcpy(buf_message,"0");
				}
				fclose(outfile);
			}

			/** if the user presses active keyword, then active users at that time is displayed.*/
			if(strcmp(receiver_name,"active")==0)
			{
				memset(receiver_name,'\0', BUFSIZE);
				flag = 1;
				for(s=0;s<40;s++)
				{	
					if(db[s].client_sockfd != 0)
					{
						/** adding a newline for better readability at the output screen. */
						strcpy(user_name,db[s].user_name);
						length=strlen(user_name);
				
						if(user_name[length-1] != '\n')
						{
							strcat(user_name,"\n");
						}
				
						/** displaying active clients.*/
		 				send(i,user_name,strlen(user_name),0); 
					}
				}
			}
				
		
			if((flag != 1) &&(flag5 == 1))
			{	
				/** messages to be sent to the registered users are stored in a temporary buffer files.*/
				strcpy(temp1,receiver_name);
				strcat(temp1,"_buffer");
				outfile=fopen (temp1,"a+");
				fprintf(outfile,"%s to %s:%s\n",sender_name,receiver_name,sender_message);
				fclose(outfile);

				/** if the user is not active error message is thrown to the particular client.*/
				send(i,not_active,strlen(not_active),0);
			}
	
			/** if the user is not exist error message is thrown to the particular client*/
			if((flag != 1) &&(flag5 != 1))
			{
				send(i,no_user,strlen(no_user),0);
			}
		}
		else
		{
			send(i,not_format,strlen(not_format),0);
		}
	}
}

/*! connection establishment takes place. */
void connection_accept(fd_set *master, int *fdmax, int server_sockfd, struct sockaddr_in *client_address)
{
	int client_sockfd;					/**< Variable to store client file descriptor */
	int nbytes_recvd;					/**< count for number of bytes received from clients */
	int client_len = sizeof(client_address);		/**< variable to store client structure length*/
	char recv_buf[BUFSIZE];					/**< Character array to store buffer message */
	char rec_buf[BUFSIZE];					/**< Character array to store buffer message */
	char *q; 						/**< pointer variable for storing a result of strstr function */	
	int len;						/**< variable for storing a length */
	int l=0,k,u,w;						/**< iterative variable */
	int y,cnt;						/**< variable for holding the result of the strcmp function */
	int flag=0,flag1=0,flag2=0,flag3=0,flag4=0,flag6=0;	/**< flag variables */
	char name[25];						/**< character array for storing username temporarily */
	char passs[25];						/**< character array for storing password temporarily */
	char temp[200],temp1[200];				/**< character array to store password, retrieved from database */
	int status;						/**< variable to hold status of strcmp function */
	char buf_message[200];					/**< character array to store messages from buffer file */
	char ch[50][200]={0},ch1=0;			       /**< character array to store usernames and password from file & temp variable*/
	int a;							/**< variable to hold length */

	/*below declared character arrays will be sent to clients to get corresponding input from them */
	char login_signup[50]="Enter 1 for login and 2 for signup\n";
	char username[25]="Enter your username: ";
	char password[25]="Set your password: ";
	char retype_password[25]="Retype your password: ";
	char login_password[25]="Enter your password: ";

	/** accept: wait for a connection request. */	
	printf("Server waiting to accept request \n");
	client_sockfd = accept( server_sockfd,(struct sockaddr *)client_address, &client_len );
	
	/** Error message for accepting client socket.
	/** if the client sockfd is greater than 0 then adding to the master set.*/
	if(client_sockfd < 0)			
	{
		error("ERROR accepting client socket:\n");
	}
	else 
	{
		FD_SET(client_sockfd, master);
		
		/** if the new client is received then its id is stored in fdmax.*/		
		if(client_sockfd > *fdmax)
		{
			*fdmax = client_sockfd;
		}	
		printf("new connection from %s on port %d \n",inet_ntoa(client_address->sin_addr), ntohs(client_address->sin_port));
	}

 	FILE *outfile;
	
	/** opening file for reading contents.*/
  	outfile = fopen("database.txt","a+");

  	/** ch is to store entire file,ch1 is for reading file char by char.*/
  	ch1=getc(outfile);
	l=0;

	while(!feof(outfile))
  	{
    		k=0;
    		while(ch1!='\n')
    		{
      			ch[l][k]=ch1;
      			k++;
      			ch1=getc(outfile);
    		}
    		ch[l][k]='\0';
    		ch1=getc(outfile);
    		l++;
  	}
	fclose(outfile);

	/** sending and receiving whether user needs to login or signup.*/
	send(client_sockfd, login_signup, strlen(login_signup), 0);	
	nbytes_recvd = recv(client_sockfd, recv_buf, BUFSIZE, 0);

	/** open database.txt for writing.*/
    	outfile=fopen ("database.txt","a+");

	/** switch statements for login and signup procedures.*/
	switch(recv_buf[0])
	{
 	 	case '2':/** this case is for signup.*/
			 /** getting username from the clients.*/

			 memset(recv_buf,'\0', BUFSIZE);
			 send(client_sockfd, username, strlen(username), 0);
			 nbytes_recvd = recv(client_sockfd, recv_buf, BUFSIZE, 0);
			 recv_buf[nbytes_recvd] = '\0';

			 /** checking whether username already exists in database.*/
			if(strlen(ch[0]) != 0)
			 {
				for(l=0;l<50;l++)
				{	
					q=strstr(ch[l],recv_buf);
					l++; 	
					if(q)
					{	
						y = strcmp(q,recv_buf);	

						if(!y)
						{
							/** if that client entered username is already taken by another client means,then displaying a error message.*/
							flag2 = 1;						
							send(client_sockfd,user_exist,strlen(user_exist),0);
							printf(" %s closed\n",recv_buf);						      
							printf("socket %d hung up\n",client_sockfd);
							close(client_sockfd);
							FD_CLR(client_sockfd, master);
							break;
						}					
					}	
				}
			 }
			 if(flag2 == 1)
			 {
				break;
			 }
			 strcpy(name,recv_buf);			 

			 /** getting password from the clients.*/
			 memset(recv_buf,'\0', BUFSIZE);
			 send(client_sockfd, password, strlen(password), 0);
			 nbytes_recvd = recv(client_sockfd, recv_buf, BUFSIZE, 0);		
			 recv_buf[nbytes_recvd] = '\0';	
			
			/** if  user presses ctrl + c, then received byte is 0 & connection is closed.*/
			if(recv_buf[0] == '\0')
			{	
				close(client_sockfd);
				FD_CLR(client_sockfd, master);
				printf("socket %d hung up\n", client_sockfd);
				break;
			}				
			 
			 /** gettting password one more time for confirmation.*/
			 memset(rec_buf,'\0', BUFSIZE);
			 send(client_sockfd, retype_password, strlen(retype_password), 0);
			 nbytes_recvd = recv(client_sockfd, rec_buf, BUFSIZE, 0);
			 rec_buf[nbytes_recvd] = '\0';	
			
			/** if  user presses ctrl + c, then received byte is 0 & connection is closed.*/
			if(recv_buf[0] == '\0')
			{	
				close(client_sockfd);
				FD_CLR(client_sockfd, master);
				printf("socket %d hung up\n", client_sockfd);
				break;
			} 
			 /** comparing password and retype password and if it not equal closes the connection by displaying a error message.*/
			 if(strcmp(recv_buf,rec_buf) == 0)
			 {	flag3=1;
				 strcpy(passs,recv_buf);
			 }
			 
			 /** if password doesn't match then client's connection is closed.*/
			 if((flag3 != 1) && (flag2 !=1))
			 {
				send(client_sockfd,signup_password, strlen(signup_password), 0);
				printf(" %s closed\n",name);				
				printf("socket %d hung up\n", client_sockfd);
				close(client_sockfd);
				FD_CLR(client_sockfd, master);
				break;
			 }
		
			 /** if username and password are matched, then writing into a structure.*/
			 if((flag3 == 1) && (flag2 != 1))
			 {
				/** writing username into file.*/
				fprintf(outfile,"user:%s\n",name);

				/** writing password into a file.*/
				fprintf(outfile,"pwd:%s\n",passs);
				memset(rec_buf,'\0', BUFSIZE);
				send(client_sockfd,alright, strlen(alright), 0);
				nbytes_recvd = recv(client_sockfd, rec_buf, BUFSIZE, 0);
				rec_buf[nbytes_recvd] = '\0';
				
			} 
				/** closing the file.*/
				fclose(outfile); 	
			
		case '1':/** this case is for login.*/			
			 /** getting username from the clients.*/
			 memset(recv_buf,'\0', BUFSIZE);
			 send(client_sockfd, username, strlen(username), 0);
			 nbytes_recvd = recv(client_sockfd, recv_buf, BUFSIZE, 0);
			recv_buf[nbytes_recvd] = '\0';
			
			/** if  user presses ctrl + c, then received byte is 0 & connection is closed.*/
			if(recv_buf[0] == '\0')
			{	
				close(client_sockfd);
				FD_CLR(client_sockfd, master);
				printf("socket %d hung up\n", client_sockfd);
				break;
			}
			 /** opening file for reading contents.*/
  			 outfile = fopen("database.txt","a+");

  			 /** ch is to store entire file,ch1 is for reading file char by char.*/
  			 ch1=getc(outfile);

			l=0;
			while(!feof(outfile))
  			{
    				k=0;
    				while(ch1!='\n')
    				{
      					ch[l][k]=ch1;
      					k++;
      					ch1=getc(outfile);
    				}
    				ch[l][k]='\0';
    				ch1=getc(outfile);
    				l++;
  			}
			fclose(outfile);
			
			/** checking with the database for a valid user.*/
			for(l=0;l<50;l++)
			{
				q=strstr(ch[l],recv_buf);
				l++;
				len = strlen(ch[l]); 	

				if(q)
				{	y = strcmp(q,recv_buf);	
					if(!y)
					{					
						flag=1;	
						strcpy(temp,"0");
						for(k = 4,u=0 ; k <= len ; k++,u++)				
						{
							temp[u]=ch[l][k];
						}
						temp[u]='\0';
						break;
						
					}
				}	
			}
			
			if(flag == 1)
			{
			
				/** getting password from the clients.*/
				memset(rec_buf,'\0', BUFSIZE);
				send(client_sockfd, login_password, strlen(login_password), 0);
				nbytes_recvd = recv(client_sockfd, rec_buf, BUFSIZE, 0);
				rec_buf[nbytes_recvd] = '\0';
				
				/** if  user presses ctrl + c, then received byte is 0 & connection is closed.*/
				if(recv_buf[0] == '\0')
				{	
					close(client_sockfd);
					FD_CLR(client_sockfd, master);
					printf("socket %d hung up\n", client_sockfd);
					break;
				}
				/** comparing the user typed password with the password in the database and if it fails server closes its connection.*/
				status=strcmp(rec_buf, temp);
				if(status != 0)
				{	
					flag1=1;
					send(client_sockfd,invalid_credentials, strlen(invalid_credentials), 0);
					printf(" %s closed\n",recv_buf);
					printf("socket %d hung up\n", client_sockfd);					
					close(client_sockfd);
					FD_CLR(client_sockfd, master);
				}
			}
			
			/** if user name not matched with the database, client connection is quitted with a error message displayed.*/
			else			
			{
				send(client_sockfd,login_user_error, strlen(login_user_error), 0);
				printf(" %s closed\n",recv_buf);	
				printf("socket %d hung up\n", client_sockfd);								
				close(client_sockfd);
				FD_CLR(client_sockfd, master);
			}
						
			/** after login user credentials are stored in temporary storage.*/
			if((flag1 != 1)&&(flag ==1))
			{	
				memset(rec_buf,'\0', BUFSIZE);
				send(client_sockfd,alright, strlen(alright), 0);
				nbytes_recvd = recv(client_sockfd, rec_buf, BUFSIZE, 0);
				rec_buf[nbytes_recvd] = '\0';
				
				strcpy(db[w].user_name,recv_buf);
				db[w].client_sockfd=client_sockfd;
	
				/** if the respective user has some message to be received, those messages are sent.*/
				strcpy(temp1,recv_buf);
				strcat(temp1,"_buffer");
				outfile=fopen (temp1,"a+");
				FILE *outfile2;				/**< creating another file pointer */
				struct stat st;
		
				if (stat(temp1, &st) == 0)
				{
			      		flag6=1;
			   	}

				if(flag6 == 1)
				{
					outfile2=fopen(recv_buf,"a+");	
					while(fscanf(outfile,"%[^\n]\n", buf_message)!=EOF)
					{
						/** adding a newline character to that message for user readability.*/
						strcat(buf_message,"\n");
						send(client_sockfd,buf_message, strlen(buf_message), 0);
						
						/** removing a newline character while storing in the file.*/
						a=strlen(buf_message);
						buf_message[a]='\0';

						/** writing those messages into the file.*/
						fprintf(outfile2,"%s\n",buf_message);
			
					}
					fclose(outfile);
					fclose(outfile2);
					remove(temp1);	
				}
			}
	
			/** incrementing a structure iterative variable for storing next client entry.*/
			w++;			
			break;
	}
}

/*! function for creating a unnamed server socket, naming it, listening and binding. */
void connect_request(int *server_sockfd, struct sockaddr_in *my_addr)
{
	int optval = 1;				/**< Flag value for setsockopt */
	int setsockopt_stat=0;			/**< Variable to store setsockopt_stat status */
	int bind_stat=0;			/**< Variable to store bind status */
	int listen_stat=0;			/**< Variable to store listen status */

	/** Removing any old sockets.*/
	printf("Unlinking old sockets\n");
	unlink("server_socket");

	/** creating an unnamed socket for the server.*/
	printf("Creating server socket\n");
	*server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
	printf("Socket created\n");
	
	/** Error message for socket creation.*/
	if (*server_sockfd < 0) 
	{
		error("Socket");
		exit(1);
	}
	
	/*! setsockopt: Handy debugging trick that lets 
	 * us rerun the server immediately after we kill it; 
	 * otherwise we have to wait about 20 secs. 
	 * Eliminates "ERROR on binding: Address already in use" error. 
	 */

	setsockopt_stat=setsockopt(*server_sockfd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)); 

	/** Error message for setsockopt.*/
	if(setsockopt_stat < 0)
	{
		error("ERROR setsockopt");
	} 
	
	/** Naming the socket.	*/
	my_addr->sin_family = AF_INET;
	my_addr->sin_port = htons(4950);
	my_addr->sin_addr.s_addr = htonl(INADDR_ANY);
	memset(my_addr->sin_zero, '\0', sizeof my_addr->sin_zero);
	
	/** Binding the server.*/
	printf("binding server\n");	
	bind_stat = bind(*server_sockfd, (struct sockaddr *)my_addr, sizeof(struct sockaddr));

	/** Error message for binding.*/
	if(bind_stat < 0)
	{
		error("ERROR binding socket");
	}
	
	/** Creating a connection queue and wait for clients.*/
	printf("Listening server\n");
	listen_stat = listen(*server_sockfd, NUM_CLIENT );

	/** Error message for listening.*/
	if(listen_stat < 0)
	{
		error("ERROR binding socket:");
	}

	printf("\nTCPServer Waiting for client on port 4950\n");
	fflush(stdout);
}

int main()
{
	fd_set master;						/**< creating a set to store client id */
	fd_set read_fds;					/**< variable to check for open file descriptor */
	int fdmax, i,s;						/**< variable holder for maximum clients and iteration variable */
	int server_sockfd= 0;					/**< Variable to store Server file descriptor */
	struct sockaddr_in server_address, client_address;	/**< sockaddr_in structure variable for server and client */
	
	/** emptying a master set.*/
	FD_ZERO(&master);		
	FD_ZERO(&read_fds);
	
	/** function call to create a socket.*/
	connect_request(&server_sockfd, &server_address); 		

	/*! Waiting for a connection request,
	 * receiving message from client &
	 * sending message to other clients */
	
	/// entering a server_sockfd into master set. 
	FD_SET(server_sockfd, &master);	
	fdmax = server_sockfd;

	while(1)
	{
		read_fds = master;
		
		/** select function to check multiple clients at a time.*/
		if(select(fdmax+1, &read_fds, NULL, NULL, NULL) == -1)		 
		{
			error("select");
			exit(4);
		}

		/** client connection establishment and sending and receiving messages among the clients.*/
		for (i = 0; i <= fdmax; i++)
		{
			if (FD_ISSET(i, &read_fds))
			{
				if (i == server_sockfd)
				{
					connection_accept(&master, &fdmax, server_sockfd, &client_address);
				}
				else
				{
					send_recv(i, &master, server_sockfd, fdmax);
				}
			}
		}
	}
	return 0;
}
