#include <ncurses.h>				/* header file for standard input and output operations and GUI applications. */
#include <stdlib.h>				/* header file for using memory related functions. */
#include <string.h>				/* header file for string operations. */
#include <unistd.h>				/* header file for miscellaneous symbolic constants and types */
#include <sys/types.h>				/* header file for os related functions. */
#include <sys/socket.h>				/* header file for socket related functions. */
#include <netinet/in.h>				/* header file for constants and structures needed for internet domain addresses */
#include <arpa/inet.h>				/* header file contains definitions for internet operations */
#include <netdb.h>				/* header file for network database operations. */
#include <errno.h>				/* header file for displaying error number. */
#include <sys/stat.h>				/* header file for structure of the data returned by stat() */
#include <signal.h>				/* header file for dealing with signals. */

#define PORT 4950
#define BUFSIZE 1024
#define NUM_CLIENT 10

/** following declarations for displaying error messages to client */
char signup_password[60]="password and retype password doesn't match";
char login_user_error[25]="no_such_client";
char invalid_credentials[25]="invalid_credentials";
char user_exist[25]="user already exist";
char alright[25]="alright";
char okay[25] = "ok";	

/*! Function for error message. */
void error(char *msg)
{
	perror(msg);
	printf ("Error %d : %s \n", errno, strerror(errno));
	exit(1);
}

struct database
{
 int client_sockfd;			/**< structure member client id */
 char user_name[20];			/**< structure member to hold client username */
 char passwd[20];			/**< structure member to hold client password */
}db[50];
