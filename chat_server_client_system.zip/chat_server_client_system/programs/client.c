/* Client side C program */

#include "header.h"			/* including "header.h" file */
	
/*! this function is for login and signup details */
void login_signup(int **sockfd,WINDOW *login_sub_win)
{	
	char send_buf[BUFSIZE];		/**< character array to store sending message */
	char recv_buf[BUFSIZE];		/**< character array to store receiving message */
	int nbyte_recvd;		/**< variable to count received message bytes */

	/** sending and receiving login and signup details */
	memset(recv_buf, '\0' , BUFSIZE);
	nbyte_recvd = recv(**sockfd, recv_buf, BUFSIZE, 0);	
	recv_buf[nbyte_recvd] = '\0';
	
	/** if everything is alright then programs proceeds to next process */
	if(strcmp(recv_buf,alright)==0)
	{
		send(**sockfd, okay, strlen(okay), 0);
		wrefresh(login_sub_win);
		return;
	}	
	wprintw(login_sub_win,"%s",recv_buf);
	wrefresh(login_sub_win);
	
	/** if the server sends error message, connection is closed */
	if((strcmp(recv_buf,signup_password)==0)||(strcmp(recv_buf,user_exist)==0)||(strcmp(recv_buf,login_user_error)==0)||(strcmp(recv_buf,invalid_credentials)==0))
	{	
		sleep(2);
		endwin();			/* End curses mode */
		printf("%s\n",recv_buf);
		exit(0);
	}
	
	memset(send_buf, '\0' , BUFSIZE);
	wgetstr(login_sub_win,send_buf);
	wrefresh(login_sub_win);
				
	if(send_buf[strlen(send_buf) - 1] == '\n')
	{
		send_buf[strlen(send_buf) - 1] = '\0';
	}
		
	send(**sockfd, send_buf, strlen(send_buf), 0);
}


		
/*! creating a socket for a client and connect with the server 	*/
void connect_request(int *sockfd, struct sockaddr_in *server_address,char *argv[])
{
	int nbyte_recvd;				/**< variable to store number of bytes received */
	struct hostent *ptrh;				/**< Pointer to a host table entry */
	char recv_buf[BUFSIZE];				/**< character array to store receiving message */
	char send_buf[BUFSIZE];				/**< character array to store sending message */
	int login_signup_var;				/**< variable to store user typed value whether login or signup */
	
	/** Create a socket for the client. */
	printf("Creating a socket \n");
	*sockfd = socket(AF_INET, SOCK_STREAM, 0);

	if (*sockfd < 0)
	{ 
        	error("ERROR opening socket");
	}

	/** Naming the socket. */
	printf("Naming the socket \n");
	server_address->sin_family = AF_INET;
	server_address->sin_port = htons(4950);
	
	/** call gethostbyname() with a host name and copy to server_address.
	 * gethostbyname() returns a pointer to a hostent struct or NULL.                             
	 */

   	ptrh = gethostbyname(argv[1]);
	if ( ((char *)ptrh) == NULL ) 
	{
		fprintf(stderr,"invalid host: %s\n", argv[1]);
		exit(1);
	}
    	memcpy(&server_address->sin_addr.s_addr,ptrh->h_addr,ptrh->h_length);


	/** Connecting to servers socket. */
	if(connect(*sockfd, (struct sockaddr *)server_address, sizeof(struct sockaddr)) <0)
	{
		perror("connect");
		exit(1);
	}
	printf("Socket connected \n");
	
	initscr();			/*! Start curses mode 		*/
	cbreak();			/*! Line buffering disabled, Pass on
						 * everty thing to me 		
						 */
	keypad(stdscr, TRUE);		/*! Get F1,F2,....keys access to stdscr */

	if(has_colors() == FALSE)
	{	endwin();
		printf("Your terminal does not support color\n");
		exit(1);
	}

	start_color();			/*! Start color*/

	/*! The function init_pair() is used to define the foreground and background for the pair number you give 
	 *  first argument is pair number,second is foreground and third is background color
	 */

	init_pair(1, COLOR_BLUE, COLOR_WHITE);	
	init_pair(2, COLOR_MAGENTA, COLOR_WHITE);

	printw("This session is for signup/login");
	refresh();

	/*! Creating login_win 
	 * using newwin(LINES, COLS, y, x); function 
	 */

	/*! Print a border around the login window using box(); function
	 * 0, 0 gives default characters for the vertical and horizontal lines	
	 */

	WINDOW *login_win;		
	login_win = newwin(15, 40, 6, 20); 
	box(login_win, 0 , 0);	
	wbkgd(login_win,COLOR_PAIR(2));		/*! Fill the login_win with color pair 2 */  		
	mvwprintw(login_win,1,1,"This is login/signup window");	/*! Start printing from the coordinate (1,1) w.r.t login_win */ 
	wrefresh(login_win); 				/*! Contents will reflect on the screen only if we call wrefresh() function */
	
	WINDOW *login_sub_win;
	login_sub_win = derwin(login_win, 12, 38 , 2, 1);
	box(login_sub_win, 0 , 0);
	wborder(login_sub_win, ' ', ' ', '-', ' ', '-', '-', ' ', ' ');
	wbkgd(login_sub_win,COLOR_PAIR(1));		/*! Fill the login_sub_win with color pair 1 */  
	wmove(login_sub_win,1,0);			/*! Move cursor position to (1,0) w.r.t login_sub_win */
	scrollok(login_sub_win,TRUE);			/*! Make login_sub_win scrollable */
	wrefresh(login_sub_win);


	/** printing the login_signup message from the server */
	memset(recv_buf, '\0' , BUFSIZE);
	nbyte_recvd = recv(*sockfd, recv_buf, BUFSIZE, 0);         
	recv_buf[nbyte_recvd] = '\0';
	wprintw(login_sub_win,"%s",recv_buf);
	wrefresh(login_sub_win);

	/** users enters whether he needs to login or he needs to do signup. */
	memset(send_buf, '\0' , BUFSIZE);
	wgetstr(login_sub_win,send_buf);
	wrefresh(login_sub_win);
		
	login_signup_var = atoi(send_buf); 
	if(login_signup_var == 1 ||login_signup_var == 2)
	{ 
		send(*sockfd, send_buf, strlen(send_buf), 0);
	}
	else
	{
		wprintw(login_sub_win,"This is last chance for you.. enter correct choice- 1 for login and 2 signup\n");
		wrefresh(login_sub_win);
		memset(send_buf, '\0' , BUFSIZE);
		wgetstr(login_sub_win,send_buf);
		wrefresh(login_sub_win);

		login_signup_var = atoi(send_buf);
		if(login_signup_var == 1 ||login_signup_var == 2)
		{ 
			send(*sockfd, send_buf, strlen(send_buf), 0);
		}
		else
		{
			wprintw(login_sub_win,"your response is incorrect... your connection is closed.. sorry for the inconvinence\n");
			wrefresh(login_sub_win);
			sleep(2);
			endwin();			/* End curses mode */
			printf("your response is incorrect... your connection is closed.. sorry for the inconvinence\n");
			exit(0);
		}
	}
	
	switch(login_signup_var)
	{
		case 2: /**this case is for signup. */
			login_signup(&sockfd,login_sub_win);
			login_signup(&sockfd,login_sub_win);
			login_signup(&sockfd,login_sub_win);
			login_signup(&sockfd,login_sub_win);

		case 1: /**this case is for login.*/
			wclear(login_sub_win);
			wborder(login_sub_win, ' ', ' ', '-', ' ', '-', '-', ' ', ' ');
			wbkgd(login_sub_win,COLOR_PAIR(1));		/*! Fill the login_sub_win with color pair 1 */
			wmove(login_sub_win,1,0);
			wprintw(login_sub_win,"now you have to login to proceed\n");
			wrefresh(login_sub_win);
			login_signup(&sockfd,login_sub_win);
			login_signup(&sockfd,login_sub_win);
			login_signup(&sockfd,login_sub_win);
			break;

		default:
			break;
	}
	clear();			/*! clear the screen */	
	endwin();			/*! End curses mode */
	refresh();
}
void handle_sigint(int sig)
{
	endwin();			/*! End curses mode */
	printf("ctrl+c entered... connection has been terminated \n");
	exit(0);
}
int main(int argc,char *argv[])
{
	signal(SIGINT, handle_sigint);
	int sockfd, fdmax, i;			/**< Variable to store client file descriptor */
	int select_stat;			/**< Variable to store select status*/
	struct sockaddr_in server_address;	/**< Sockaddr_in structure variable for client*/
	char send_buf[BUFSIZE];			/**< Variable to store sender message */
	char recv_buf[BUFSIZE];			/**< Variable to store receiver message */
	int nbyte_recvd;			/**< Variable to count no. of bytes received*/

	fd_set master;
	fd_set read_fds;

	/** Verify a "hostname" parameter was supplied */
   	if (argc < 2 || *argv[1] == '\0')
      		exit(EXIT_FAILURE);

	/*! function call to request a connection from the server. */
	connect_request(&sockfd, &server_address,argv);

	FD_ZERO(&master);	
        FD_ZERO(&read_fds);	
        FD_SET(0, &master);	
        FD_SET(sockfd, &master);
	
	fdmax = sockfd;

	int width, height;

	initscr();			/*! Start curses mode 		*/
	clear();			/*! clear the screen */
	cbreak();			/*! Line buffering disabled, Pass on
						 * everything to me
						 */
	keypad(stdscr, TRUE);		/*! Get F1,F2,....keys access to stdscr */

	if(has_colors() == FALSE)
	{	endwin();
		printf("Your terminal does not support color\n");
		exit(1);
	}

	start_color();			/*! Start color*/

	/*! The function init_pair() is used to define the foreground and background for the pair number you give 
	 *  first argument is pair number,second is foreground and third is background color
	 */

	init_pair(1, COLOR_RED, COLOR_WHITE);	
	init_pair(2, COLOR_BLACK, COLOR_WHITE);
	init_pair(3, COLOR_GREEN, COLOR_BLUE);
	init_pair(4, COLOR_WHITE, COLOR_BLUE);

	printw("This session is for sending/receiving message");
	refresh();

	height = LINES - 1; /**< LINES are the total no. of rows of stdscr */
	width = (COLS/2) - 1;	/**< COLS are the total no. of columns of stdscr */

	/*! Creating send_win at top left corner opf stdscr 
	 * using newwin(LINES, COLS, y, x); function 
	 */

	/*! Print a border around the main send window using box(); function
	 * 0, 0 gives default characters for the vertical and horizontal lines	
	 */

	WINDOW *send_win;		
	send_win = newwin(height, width, 1, 1); 
	box(send_win, 0 , 0);		
	wbkgd(send_win,COLOR_PAIR(2));  		/*! Fill the send_wind with color pair 2 */	
	mvwprintw(send_win,1,1,"This is send window");	/*! Start printing from the coordinate (1,1) w.r.t send_win */ 
	wrefresh(send_win); 				/*! Contents will reflect on the screen only if we call refresh() function */

	/*! create send_sub_win w.r.t send_win using 
	 *  derwin(WINDOW *orig, int nlines, int ncols, int begin_y, int begin_x); function */

	/*! Print a border around the sub window using box(); function
	 * 0, 0 gives default characters for the vertical and horizontal lines	
	 */

	/*! The parameters taken by wborder(); function
	 * 1. win: the window on which to operate
	 * 2. ls: character to be used for the left side of the window 
	 * 3. rs: character to be used for the right side of the window 
	 * 4. ts: character to be used for the top side of the window 
	 * 5. bs: character to be used for the bottom side of the window 
	 * 6. tl: character to be used for the top left corner of the window 
	 * 7. tr: character to be used for the top right corner of the window 
	 * 8. bl: character to be used for the bottom left corner of the window 
	 * 9. br: character to be used for the bottom right corner of the window
	 */

	WINDOW *send_sub_win;
	send_sub_win = derwin(send_win, height-3, width-2 , 2, 1);
	box(send_sub_win, 0 , 0);
	wborder(send_sub_win, ' ', ' ', '-', ' ', '-', '-', ' ', ' ');  
	wbkgd(send_sub_win,COLOR_PAIR(1));		/*! Fill the send_win with color pair 1 */
	wmove(send_sub_win,1,0);			/*! Move cursor position to (1,0) w.r.t send_sub_win */
	scrollok(send_sub_win,TRUE);			/*! Make send_sub_win scrollable */
	wrefresh(send_sub_win);

	/*! Creating recv_win at bottom right corner of stdscr 
	 * using newwin(LINES, COLS, y, x); function.  
	 */

	/*! Print a border around the main receive window using box(); function
	 * 0, 0 gives default characters for the vertical and horizontal lines	
	 */

	WINDOW *recv_win;
	recv_win = newwin(height, width, 1, (COLS/2) + 1);
	box(recv_win, 0 , 0);
	wbkgd(recv_win,COLOR_PAIR(4));
	mvwprintw(recv_win,1,1,"This is receive window");
	wrefresh(recv_win);	
	
	/*! create recv_sub_win w.r.t recv_win using 
	 *  derwin(WINDOW *orig, int nlines, int ncols, int begin_y, int begin_x); function 
	 */

	/*! Print a border around the sub window using box(); function
	 * 0, 0 gives default characters for the vertical and horizontal lines	
	 */

	/*! The parameters taken by wborder(); function
	 * 1. win: the window on which to operate
	 * 2. ls: character to be used for the left side of the window 
	 * 3. rs: character to be used for the right side of the window 
	 * 4. ts: character to be used for the top side of the window 
	 * 5. bs: character to be used for the bottom side of the window 
	 * 6. tl: character to be used for the top left corner of the window 
	 * 7. tr: character to be used for the top right corner of the window 
	 * 8. bl: character to be used for the bottom left corner of the window 
	 * 9. br: character to be used for the bottom right corner of the window
	 */

	WINDOW *recv_sub_win;
	recv_sub_win = derwin(recv_win, height-3, width-2 , 2, 1);
	box(recv_sub_win, 0 , 0);		
	wborder(recv_sub_win, ' ', ' ', '-', ' ', '-', '-', ' ', ' ');
	wbkgd(recv_sub_win,COLOR_PAIR(3));		/*! Fill the send_win with color pair 3 */
	wmove(recv_sub_win,1,0);			/*! Move cursor position to (1,0) w.r.t recv_sub_win */
	scrollok(recv_sub_win,TRUE);			/*! Make send_sub_win scrollable */
	wrefresh(recv_sub_win);	
	
	
	while(1)
	{
		read_fds = master;
		select_stat=select(fdmax+1, &read_fds, NULL, NULL, NULL);
		if(select_stat < 0)
		{
			perror("select");
			exit(4);
		}
		/** Loop through all the open file descriptors,
	 	 *  if particular clients sockfd present in the data set then
		 *  send or receive from particular client 
		 */
		for(i=0; i <= fdmax; i++ )
		{	if(FD_ISSET(i, &read_fds)) 
			{
				/** If there is any standard input (file descriptor of stdin is 0) then
				 * get string from the user and send to the client 
				 * else receive from the user
				 */ 
				if (i == 0){
					wgetstr(send_sub_win,send_buf);
					wrefresh(send_sub_win);

						if (strcmp(send_buf , "quit") == 0) {
							/** If user enters quit then deallocate memory w.r.t window
							 * and end the curses mode 
							 */
 
							delwin(send_sub_win); 
							wborder(send_win, ' ', ' ', ' ',' ',' ',' ',' ',' ');
							wrefresh(send_win);
							delwin(send_win);

							delwin(recv_sub_win);			
							wborder(recv_win, ' ', ' ', ' ',' ',' ',' ',' ',' ');			
							wrefresh(recv_win);			
							delwin(recv_win);
							endwin();			/* End curses mode		  */
							
							exit(0);
						}else
							send(sockfd, send_buf, strlen(send_buf), 0);
				}else {
					nbyte_recvd = recv(sockfd, recv_buf, BUFSIZE, 0);
					recv_buf[nbyte_recvd] = '\0';
					wprintw(recv_sub_win,"%s\n",recv_buf);
					wrefresh(recv_sub_win);
					fflush(stdout);
				}
			}
		}
	}

	/** closing the client. */
	printf("client-quited\n");
	close(sockfd);
	return 0;
}
